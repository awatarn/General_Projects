% Compiles a Fortran main source file. Assumes engine routines are used.
% Intel 9.1 compiler
function compile_intel91(name)
options = [matlabroot '\bin\win32\mexopts\intel91engmatopts.bat'];
disp(['Options = ' options]);
mex('-f', options, name, '-v');
end